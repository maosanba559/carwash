<template>
	<view>
		<uni-icons type="closeempty" size="12" color="#6c757d"
		class="bg-light position-absolute d-flex a-cente j-center"
		 style="height: 45rpx;line-height: 45rpx;width: 45rpx;border-radius: 50%;right: 10rpx; top:10rpx"></uni-icons>
	</view>
</template>

<script>
</script>

<style>

</style>