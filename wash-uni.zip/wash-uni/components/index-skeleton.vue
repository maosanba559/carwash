
<template name="skeleton">
  <view class="sk-container">
    <view>
      <view>
        <view style="height:350rpx;"></view>
        <view>
			<view class="mx-2 mt-2">
              <view class="d-flex font-md font-weight bg-white a-center j-center rounded-20 " 
			  style="height: 160rpx;">
                <view class="text-center flex-1" >
                  <image class="svgsmall sk-image"></image>
                  <view class="mt-1 sk-transparent sk-text-33-3333-767 sk-text" style="background-position-x: 50%;"></view>
                </view>
                <view class="text-center flex-1" >
                  <image class="svgsmall sk-image"></image>
                  <view class="mt-1 sk-transparent sk-text-33-3333-466 sk-text" style="background-position-x: 50%;"></view>
                </view>
                <view class="text-center flex-1" >
                  <image class="svgsmall sk-image"></image>
                  <view class="mt-1 sk-transparent sk-text-33-3333-597 sk-text" style="background-position-x: 50%;"></view>
                </view>
                <view class="text-center flex-1" >
                  <image class="svgsmall sk-image"></image>
                  <view class="mt-1 sk-transparent sk-text-33-3333-525 sk-text" style="background-position-x: 50%;"></view>
                </view>
              </view>
      <divider/>
        <view>
          <view class="uni-section section--uni-section rounded-20">
            <view class="uni-section-header section--uni-section-header">
              <view class="uni-section__content section--uni-section__content">
                <text class="uni-section__content-title section--uni-section__content-title distraction section--distraction sk-transparent sk-text-14-2857-702 sk-text" style="color:#333;">附近门店</text>
              </view>
            </view>
            <view style="padding:;">
              <view>
                <view>
                  <view class="d-flex list--d-flex p-2 list--p-2 a-center list--a-center border-bottom list--border-bottom position-relative list--position-relative" >
                    <view class="d-flex list--d-flex flex-column list--flex-column pr-1 list--pr-1" >
                      <image lazy-load="true" style="width:90px;height:75px;border-radius:5px 5px 0 0;" class="sk-image"></image>
                      <view class="text-center list--text-center border list--border line-h-lg list--line-h-lg mr-1 list--mr-1 text-muted list--text-muted sk-transparent" style="border-radius: 0px 0px 5px 5px; border: none;">
                        <view>
                          <text class="uni-icons icons--uni-icons uniui-map-pin-ellipse icons--uniui-map-pin-ellipse sk-pseudo sk-pseudo-circle" ></text>
                        </view>导航</view>
                    </view>
					<view class="flex-1 list--flex-1">
                      <view class="sk-transparent sk-text-14-2857-679 sk-text">UU三毛自助洗车西吴店</view>
                      <view class="d-flex list--d-flex">
                        <view class="utag list--utag sk-transparent sk-text-14-2857-400 sk-text" style="background-color:#2979ff;">工位: 1</view>
                        <view class="utag list--utag sk-transparent sk-text-14-2857-350 sk-text" style="background-color:#18bc37;">空闲：1</view>
                      </view>
                      <view class="d-flex list--d-flex flex-wrap list--flex-wrap">
                        <view class="utag list--utag sk-transparent sk-text-14-2857-644 sk-text">7元10分钟</view>
                        <view class="utag list--utag sk-transparent sk-text-14-2857-684 sk-text">超出每分钟0.5元</view>
                      </view>
                      <view class="d-flex list--d-flex a-center list--a-center mt-1 list--mt-1 line-h list--line-h">
                        <view>
                          <text class="uni-icons icons--uni-icons uniui-location icons--uniui-location sk-pseudo sk-pseudo-circle"  style="color:#333333;font-size:16px;"></text>
                        </view>
                      </view>
                    </view>
                    
                  </view>
                </view>
              </view>
            </view>
          </view>
        </view>
		</view>
        </view>
      </view>
    </view>
  </view>
</template>
<style>
	.sk-transparent {
	    color: transparent !important;
	  }
	.sk-text-14-2857-410 {
	    background-image: linear-gradient(transparent 14.2857%, #FFFFFF 0%, #FFFFFF 85.7143%, transparent 0%) !important;
	    background-size: 100% 39.2000rpx;
	    position: relative !important;
	  }
	.sk-text {
	    background-origin: content-box !important;
	    background-clip: content-box !important;
	    background-color: transparent !important;
	    color: transparent !important;
	    background-repeat: repeat-y !important;
	  }
	.sk-text-33-3333-767 {
	    background-image: linear-gradient(transparent 33.3333%, #FFFFFF 0%, #FFFFFF 66.6667%, transparent 0%) !important;
	    background-size: 100% 72.0000rpx;
	    position: relative !important;
	  }
	.sk-text-33-3333-466 {
	    background-image: linear-gradient(transparent 33.3333%, #FFFFFF 0%, #FFFFFF 66.6667%, transparent 0%) !important;
	    background-size: 100% 72.0000rpx;
	    position: relative !important;
	  }
	.sk-text-33-3333-597 {
	    background-image: linear-gradient(transparent 33.3333%, #FFFFFF 0%, #FFFFFF 66.6667%, transparent 0%) !important;
	    background-size: 100% 72.0000rpx;
	    position: relative !important;
	  }
	.sk-text-33-3333-525 {
	    background-image: linear-gradient(transparent 33.3333%, #FFFFFF 0%, #FFFFFF 66.6667%, transparent 0%) !important;
	    background-size: 100% 72.0000rpx;
	    position: relative !important;
	  }
	.sk-text-14-2857-702 {
	    background-image: linear-gradient(transparent 14.2857%, #FFFFFF 0%, #FFFFFF 85.7143%, transparent 0%) !important;
	    background-size: 100% 39.2000rpx;
	    position: relative !important;
	  }
	.sk-text-14-2857-679 {
	    background-image: linear-gradient(transparent 14.2857%, #EEEEEE 0%, #EEEEEE 85.7143%, transparent 0%) !important;
	    background-size: 100% 44.8000rpx;
	    position: relative !important;
	  }
	.sk-text-14-2857-400 {
	    background-image: linear-gradient(transparent 14.2857%, #FFFFFF 0%, #FFFFFF 85.7143%, transparent 0%) !important;
	    background-size: 100% 30.8000rpx;
	    position: relative !important;
	  }
	.sk-text-14-2857-350 {
	    background-image: linear-gradient(transparent 14.2857%, #FFFFFF 0%, #FFFFFF 85.7143%, transparent 0%) !important;
	    background-size: 100% 30.8000rpx;
	    position: relative !important;
	  }
	.sk-text-14-2857-644 {
	    background-image: linear-gradient(transparent 14.2857%, #FFFFFF 0%, #FFFFFF 85.7143%, transparent 0%) !important;
	    background-size: 100% 30.8000rpx;
	    position: relative !important;
	  }
	.sk-text-14-2857-684 {
	    background-image: linear-gradient(transparent 14.2857%, #FFFFFF 0%, #FFFFFF 85.7143%, transparent 0%) !important;
	    background-size: 100% 30.8000rpx;
	    position: relative !important;
	  }
	.sk-text-0-0000-324 {
	    background-image: linear-gradient(transparent 0.0000%, #FFFFFF 0%, #FFFFFF 100.0000%, transparent 0%) !important;
	    background-size: 100% 22.0000rpx;
	    position: relative !important;
	  }
	.sk-image {
	    background: #EFEFEF !important;
	  }
	.sk-pseudo::before, .sk-pseudo::after {
	      background: #FFFFFF !important;
	      background-image: none !important;
	      color: transparent !important;
	      border-color: transparent !important;
	    }
	.sk-pseudo-rect::before, .sk-pseudo-rect::after {
	      border-radius: 0 !important;
	    }
	.sk-pseudo-circle::before, .sk-pseudo-circle::after {
	      border-radius: 50% !important;
	    }
	.sk-container {
	    position: absolute;
	    left: 0;
	    top: 0;
	    width: 100%;
	    height: 100%;
	    overflow: hidden;
	    background-color: transparent;
	  }
</style>